module.exports = {
    SESSION_TTL: 60 * 15
}